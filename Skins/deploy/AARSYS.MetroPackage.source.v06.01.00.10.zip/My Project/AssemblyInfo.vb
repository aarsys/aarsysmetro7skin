﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' Allgemeine Informationen über eine Assembly werden über die folgenden 
' Attribute gesteuert. Ändern Sie diese Attributwerte, um die Informationen zu ändern,
' die mit einer Assembly verknüpft sind.

' Die Werte der Assemblyattribute überprüfen

<Assembly: AssemblyTitle("Aarsys Metro Skin")> 
<Assembly: AssemblyDescription("4 color Metro style skin package for DotNetnuke")> 
<Assembly: AssemblyCompany("Aarsys - Matthias Schlomann")> 
<Assembly: AssemblyProduct("Metro7SkinPackage")> 
<Assembly: AssemblyCopyright("Copyright ©  2012 Aarsys - Matthias Schlomann")> 
<Assembly: AssemblyTrademark("http://www.aarsys.de")> 

<Assembly: ComVisible(False)> 

'Die folgende GUID bestimmt die ID der Typbibliothek, wenn dieses Projekt für COM verfügbar gemacht wird
<Assembly: Guid("131642f0-d2eb-444e-9449-c9467d7d2d57")> 

' Versionsinformationen für eine Assembly bestehen aus den folgenden vier Werten:
'
'      Hauptversion
'      Nebenversion 
'      Buildnummer
'      Revision
'
' Sie können alle Werte angeben oder die standardmäßigen Build- und Revisionsnummern 
' übernehmen, indem Sie "*" eingeben:

<Assembly: AssemblyVersion("06.01.00.02")> 
<Assembly: AssemblyFileVersion("06.01.00.02")> 
