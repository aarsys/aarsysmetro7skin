﻿'------------------------------------------------------------------------------
' <automatisch generiert>
'     Der Code wurde von einem Tool generiert.
'
'     Änderungen an der Datei führen möglicherweise zu falschem Verhalten, und sie gehen verloren, wenn
'     der Code erneut generiert wird. 
' </automatisch generiert>
'------------------------------------------------------------------------------

Option Strict On
Option Explicit On

Namespace DotNetNuke.UI.Skins
    
    Partial Public Class Skin
        
        '''<summary>
        '''ContentPane-Steuerelement
        '''</summary>
        '''<remarks>
        '''Automatisch generiertes Feld
        '''Um dies zu ändern, verschieben Sie die Felddeklaration aus der Designerdatei in eine Code-Behind-Datei.
        '''</remarks>
        Protected WithEvents ContentPane As Global.System.Web.UI.HtmlControls.HtmlGenericControl
    End Class
End Namespace
